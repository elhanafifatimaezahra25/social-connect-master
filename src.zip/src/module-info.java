module javafx.social.platform {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
	requires jbcrypt;
    
    opens app to javafx.fxml;
    opens app.controllers to javafx.fxml;
    opens app.models to javafx.base;
    
    exports app;
    exports app.controllers;
    exports app.models;
    exports app.dao;
    exports app.utils;
    exports app.database;
}
