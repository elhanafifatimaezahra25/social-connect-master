package app.controllers;

import app.dao.UserDAO;
import app.models.User;
import app.utils.PasswordUtil;
import app.utils.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;
    @FXML private Button loginButton;

    private UserDAO userDAO = new UserDAO();

    @FXML
    public void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        // Validation
        if (username.isEmpty() || password.isEmpty()) {
            showError("Please fill in all fields");
            return;
        }

        // Authenticate user
        User user = userDAO.getUserByUsername(username);
        
        if (user == null) {
            showError("Invalid username or password");
            return;
        }

        // Verify password
        if (!PasswordUtil.verifyPassword(password, user.getPasswordHash())) {
            showError("Invalid username or password");
            return;
        }

        // Login successful
        System.out.println(" Login successful for user: " + user.getUsername());
        SessionManager.getInstance().setCurrentUser(user);
        System.out.println(" Session set successfully");
        
        try {
            // Navigate to feed
            System.out.println(" Loading feed screen...");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/feed.fxml"));
            
            if (loader.getLocation() == null) {
                System.err.println(" ERROR: feed.fxml not found!");
                showError("Error: feed.fxml not found");
                return;
            }
            
            System.out.println(" Found feed.fxml at: " + loader.getLocation());
            Scene scene = new Scene(loader.load(), 1000, 700);
            scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
            
            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Social Connect - Feed");
            System.out.println(" Successfully navigated to feed!");
        } catch (Exception e) {
            System.err.println(" ERROR loading feed:");
            e.printStackTrace();
            showError("Error loading feed: " + e.getMessage());
        }
    }

    @FXML
    public void handleGoToRegister() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/register.fxml"));
            Scene scene = new Scene(loader.load(), 500, 700);
            scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
            
            Stage stage = (Stage) loginButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Social Connect - Register");
        } catch (Exception e) {
            e.printStackTrace();
            showError("Error loading registration page");
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
        errorLabel.setManaged(true);
    }
}
