package app.controllers;

import app.dao.UserDAO;
import app.models.User;
import app.utils.ThemeManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Insets;

import java.util.List;

public class SearchController {

    @FXML private TextField searchField;
    @FXML private Button searchButton;
    @FXML private ScrollPane scrollPane;
    @FXML private VBox resultsContainer;
    @FXML private Button backButton;

    private UserDAO userDAO;

    public void initialize() {
        userDAO = new UserDAO();
        
        // Auto-search on text change
        searchField.textProperty().addListener((obs, old, newVal) -> {
            if (newVal.length() >= 2) {
                performSearch(newVal);
            } else if (newVal.isEmpty()) {
                resultsContainer.getChildren().clear();
            }
        });
    }

    @FXML
    private void handleSearch() {
        String query = searchField.getText().trim();
        if (!query.isEmpty()) {
            performSearch(query);
        }
    }

    private void performSearch(String query) {
        resultsContainer.getChildren().clear();
        
        // Search users
        List<User> users = userDAO.searchUsers(query);
        
        if (users.isEmpty()) {
            Label emptyLabel = new Label("No users found for: " + query);
            emptyLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: gray; -fx-padding: 20px;");
            resultsContainer.getChildren().add(emptyLabel);
            return;
        }
        
        Label headerLabel = new Label("Found " + users.size() + " user(s):");
        headerLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-padding: 10px;");
        resultsContainer.getChildren().add(headerLabel);
        
        for (User user : users) {
            resultsContainer.getChildren().add(createUserCard(user));
        }
    }

    private VBox createUserCard(User user) {
        VBox card = new VBox(10);
        card.setPadding(new Insets(15));
        card.getStyleClass().add("post-card");
        
        Label usernameLabel = new Label("@" + user.getUsername());
        usernameLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        
        if (user.getBio() != null && !user.getBio().isEmpty()) {
            Label bioLabel = new Label(user.getBio());
            bioLabel.setWrapText(true);
            bioLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: gray;");
            card.getChildren().add(bioLabel);
        }
        
        Button viewProfileButton = new Button("View Profile");
        viewProfileButton.getStyleClass().add("primary-button");
        viewProfileButton.setOnAction(e -> navigateToProfile(user.getId()));
        
        card.getChildren().addAll(usernameLabel, viewProfileButton);
        return card;
    }

    private void navigateToProfile(int userId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/profile.fxml"));
            Scene scene = new Scene(loader.load());
            ThemeManager.initialize(scene);
            
            ProfileController controller = loader.getController();
            controller.loadUserProfile(userId);
            
            Stage stage = (Stage) searchButton.getScene().getWindow();
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/feed.fxml"));
            Scene scene = new Scene(loader.load());
            ThemeManager.initialize(scene);
            
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
