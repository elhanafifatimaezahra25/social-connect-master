package app.controllers;

import app.dao.*;
import app.models.*;
import app.utils.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class FeedController {

    @FXML private Text welcomeText;
    @FXML private TextArea postContentArea;
    @FXML private VBox postsContainer;
    @FXML private TextField searchField;
    @FXML private Button profileButton;

    private PostDAO postDAO = new PostDAO();
    private LikeDAO likeDAO = new LikeDAO();
    private CommentDAO commentDAO = new CommentDAO();
    private UserDAO userDAO = new UserDAO();

    private User currentUser;

    @FXML
    public void initialize() {
        currentUser = SessionManager.getInstance().getCurrentUser();
        
        if (currentUser != null) {
            welcomeText.setText("Welcome, " + currentUser.getUsername() + "!");
            loadPosts();
        }
    }

    @FXML
    public void handleCreatePost() {
        String content = postContentArea.getText().trim();

        if (content.isEmpty()) {
            showAlert("Error", "Post content cannot be empty");
            return;
        }

        if (content.length() > 500) {
            showAlert("Error", "Post content is too long (max 500 characters)");
            return;
        }

        Post newPost = new Post(currentUser.getId(), content);
        Post createdPost = postDAO.createPost(newPost);

        if (createdPost != null) {
            postContentArea.clear();
            loadPosts(); // Refresh feed
        } else {
            showAlert("Error", "Failed to create post");
        }
    }

    @FXML
    public void handleSearch() {
        String query = searchField.getText().trim();
        
        if (query.isEmpty()) {
            loadPosts();
            return;
        }

        // Search users and display results
        List<User> users = userDAO.searchUsers(query);
        
        postsContainer.getChildren().clear();
        
        if (users.isEmpty()) {
            Text noResults = new Text("No users found matching '" + query + "'");
            noResults.setStyle("-fx-font-size: 16px; -fx-fill: #95a5a6;");
            postsContainer.getChildren().add(noResults);
        } else {
            for (User user : users) {
                VBox userCard = createUserCard(user);
                postsContainer.getChildren().add(userCard);
            }
        }
    }

    @FXML
    public void handleGoToProfile() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/profile.fxml"));
            Scene scene = new Scene(loader.load(), 1000, 700);
            scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
            
            ProfileController controller = loader.getController();
            controller.loadUserProfile(currentUser.getId());
            
            Stage stage = (Stage) profileButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Social Connect - Profile");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load profile");
        }
    }

    @FXML
    public void handleLogout() {
        SessionManager.getInstance().logout();
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/login.fxml"));
            Scene scene = new Scene(loader.load(), 500, 600);
            scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
            
            Stage stage = (Stage) profileButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Social Connect - Login");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadPosts() {
        postsContainer.getChildren().clear();
        
        List<Post> posts = postDAO.getAllPosts();
        
        if (posts.isEmpty()) {
            Text noPosts = new Text("No posts yet. Be the first to post!");
            noPosts.setStyle("-fx-font-size: 16px; -fx-fill: #95a5a6;");
            postsContainer.getChildren().add(noPosts);
        } else {
            for (Post post : posts) {
                VBox postCard = createPostCard(post);
                postsContainer.getChildren().add(postCard);
            }
        }
    }

    private VBox createPostCard(Post post) {
        VBox card = new VBox(15);
        card.getStyleClass().add("post-card");
        card.setPadding(new Insets(20));

        // Post header (username, date)
        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);

        Text username = new Text(post.getUsername());
        username.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-fill: #2c3e50;");
        username.setOnMouseClicked(e -> viewUserProfile(post.getUserId()));
        username.setStyle(username.getStyle() + "; -fx-cursor: hand;");

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm");
        Text date = new Text(" • " + post.getCreatedAt().format(formatter));
        date.setStyle("-fx-font-size: 14px; -fx-fill: #95a5a6;");

        header.getChildren().addAll(username, date);

        // Post content
        Text content = new Text(post.getContent());
        content.setWrappingWidth(900);
        content.setStyle("-fx-font-size: 15px; -fx-fill: #34495e;");

        // Engagement bar (likes, comments)
        HBox engagementBar = new HBox(15);
        engagementBar.setAlignment(Pos.CENTER_LEFT);

        boolean isLiked = likeDAO.isPostLikedByUser(currentUser.getId(), post.getId());
        
        Button likeButton = new Button(isLiked ? "❤️ " + post.getLikeCount() : "🤍 " + post.getLikeCount());
        likeButton.getStyleClass().add("engagement-button");
        likeButton.setOnAction(e -> handleLikePost(post, likeButton));

        Button commentButton = new Button("💬 " + post.getCommentCount());
        commentButton.getStyleClass().add("engagement-button");
        commentButton.setOnAction(e -> handleViewComments(post));

        engagementBar.getChildren().addAll(likeButton, commentButton);

        card.getChildren().addAll(header, content, engagementBar);

        return card;
    }

    private VBox createUserCard(User user) {
        VBox card = new VBox(10);
        card.getStyleClass().add("post-card");
        card.setPadding(new Insets(15));

        Text username = new Text(user.getUsername());
        username.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-fill: #2c3e50;");

        Text bio = new Text(user.getBio() != null ? user.getBio() : "No bio available");
        bio.setWrappingWidth(900);
        bio.setStyle("-fx-font-size: 14px; -fx-fill: #7f8c8d;");

        Button viewProfileButton = new Button("View Profile");
        viewProfileButton.getStyleClass().add("primary-button");
        viewProfileButton.setOnAction(e -> viewUserProfile(user.getId()));

        card.getChildren().addAll(username, bio, viewProfileButton);

        return card;
    }

    private void handleLikePost(Post post, Button likeButton) {
        int userId = currentUser.getId();
        int postId = post.getId();

        boolean isCurrentlyLiked = likeDAO.isPostLikedByUser(userId, postId);

        if (isCurrentlyLiked) {
            // Unlike
            if (likeDAO.unlikePost(userId, postId)) {
                postDAO.decrementLikeCount(postId);
                post.setLikeCount(post.getLikeCount() - 1);
                likeButton.setText("🤍 " + post.getLikeCount());
            }
        } else {
            // Like
            if (likeDAO.likePost(userId, postId)) {
                postDAO.incrementLikeCount(postId);
                post.setLikeCount(post.getLikeCount() + 1);
                likeButton.setText("❤️ " + post.getLikeCount());
            }
        }
    }

    private void handleViewComments(Post post) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Comments");
        dialog.setHeaderText("Comments on " + post.getUsername() + "'s post");

        VBox dialogContent = new VBox(15);
        dialogContent.setPadding(new Insets(20));
        dialogContent.setPrefWidth(500);

        // Comments list
        ScrollPane commentsScroll = new ScrollPane();
        VBox commentsList = new VBox(10);
        commentsScroll.setContent(commentsList);
        commentsScroll.setFitToWidth(true);
        commentsScroll.setPrefHeight(300);

        List<Comment> comments = commentDAO.getCommentsByPostId(post.getId());
        
        if (comments.isEmpty()) {
            Text noComments = new Text("No comments yet. Be the first!");
            noComments.setStyle("-fx-fill: #95a5a6;");
            commentsList.getChildren().add(noComments);
        } else {
            for (Comment comment : comments) {
                VBox commentBox = new VBox(5);
                commentBox.setStyle("-fx-background-color: #ecf0f1; -fx-padding: 10; -fx-background-radius: 5;");
                
                Text commentUser = new Text(comment.getUsername());
                commentUser.setStyle("-fx-font-weight: bold; -fx-font-size: 13px;");
                
                Text commentContent = new Text(comment.getContent());
                commentContent.setWrappingWidth(450);
                commentContent.setStyle("-fx-font-size: 13px;");
                
                commentBox.getChildren().addAll(commentUser, commentContent);
                commentsList.getChildren().add(commentBox);
            }
        }

        // Add comment area
        TextArea newCommentArea = new TextArea();
        newCommentArea.setPromptText("Write a comment...");
        newCommentArea.setPrefRowCount(2);

        Button addCommentButton = new Button("Add Comment");
        addCommentButton.setOnAction(e -> {
            String commentText = newCommentArea.getText().trim();
            if (!commentText.isEmpty()) {
                Comment newComment = new Comment(post.getId(), currentUser.getId(), commentText);
                Comment created = commentDAO.createComment(newComment);
                if (created != null) {
                    postDAO.incrementCommentCount(post.getId());
                    dialog.close();
                    loadPosts(); // Refresh to show updated comment count
                }
            }
        });

        dialogContent.getChildren().addAll(commentsScroll, newCommentArea, addCommentButton);
        dialog.getDialogPane().setContent(dialogContent);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);

        dialog.showAndWait();
    }

    private void viewUserProfile(int userId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/profile.fxml"));
            Scene scene = new Scene(loader.load(), 1000, 700);
            scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
            
            ProfileController controller = loader.getController();
            controller.loadUserProfile(userId);
            
            Stage stage = (Stage) profileButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Social Connect - Profile");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load profile");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
