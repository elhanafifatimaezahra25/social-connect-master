package app.controllers;

import app.DBConnection;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class HomeController {

    @FXML
    private Label resultLabel;

    @FXML
    public void initialize() {
        try {
            Connection conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT NOW() AS time");

            if (rs.next()) {
                resultLabel.setText("MySQL time: " + rs.getString("time"));
            }

        } catch (Exception e) {
            resultLabel.setText("Error connecting to DB.");
            e.printStackTrace();
        }
    }
}
