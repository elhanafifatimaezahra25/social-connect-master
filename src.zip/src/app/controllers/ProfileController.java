package app.controllers;

import app.dao.*;
import app.models.*;
import app.utils.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public class ProfileController {

    @FXML private Text usernameText;
    @FXML private Text bioText;
    @FXML private Text postsCountText;
    @FXML private Text followersCountText;
    @FXML private Text followingCountText;
    @FXML private Button actionButton;
    @FXML private VBox userPostsContainer;

    private UserDAO userDAO = new UserDAO();
    private PostDAO postDAO = new PostDAO();
    private FollowDAO followDAO = new FollowDAO();
    private LikeDAO likeDAO = new LikeDAO();

    private User currentUser;
    private User profileUser;

    public void loadUserProfile(int userId) {
        currentUser = SessionManager.getInstance().getCurrentUser();
        profileUser = userDAO.getUserById(userId);

        if (profileUser == null) {
            showAlert("Error", "User not found");
            return;
        }

        displayUserInfo();
        displayUserPosts();
    }

    private void displayUserInfo() {
        usernameText.setText(profileUser.getUsername());
        bioText.setText(profileUser.getBio() != null ? profileUser.getBio() : "No bio available");

        // Get statistics
        List<Post> userPosts = postDAO.getPostsByUserId(profileUser.getId());
        int followersCount = followDAO.getFollowerCount(profileUser.getId());
        int followingCount = followDAO.getFollowingCount(profileUser.getId());

        postsCountText.setText(String.valueOf(userPosts.size()));
        followersCountText.setText(String.valueOf(followersCount));
        followingCountText.setText(String.valueOf(followingCount));

        // Configure action button
        if (profileUser.getId() == currentUser.getId()) {
            // Own profile - show Edit button
            actionButton.setText("Edit Profile");
            actionButton.setOnAction(e -> handleEditProfile());
        } else {
            // Other user's profile - show Follow/Unfollow button
            boolean isFollowing = followDAO.isFollowing(currentUser.getId(), profileUser.getId());
            actionButton.setText(isFollowing ? "Unfollow" : "Follow");
            actionButton.setOnAction(e -> handleFollowToggle());
        }
    }

    private void displayUserPosts() {
        userPostsContainer.getChildren().clear();

        List<Post> posts = postDAO.getPostsByUserId(profileUser.getId());

        if (posts.isEmpty()) {
            Text noPosts = new Text("No posts yet");
            noPosts.setStyle("-fx-font-size: 16px; -fx-fill: #95a5a6;");
            userPostsContainer.getChildren().add(noPosts);
        } else {
            for (Post post : posts) {
                VBox postCard = createPostCard(post);
                userPostsContainer.getChildren().add(postCard);
            }
        }
    }

    private VBox createPostCard(Post post) {
        VBox card = new VBox(15);
        card.getStyleClass().add("post-card");
        card.setPadding(new Insets(20));

        // Post header (date)
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm");
        Text date = new Text(post.getCreatedAt().format(formatter));
        date.setStyle("-fx-font-size: 14px; -fx-fill: #95a5a6;");

        // Post content
        Text content = new Text(post.getContent());
        content.setWrappingWidth(900);
        content.setStyle("-fx-font-size: 15px; -fx-fill: #34495e;");

        // Engagement bar
        HBox engagementBar = new HBox(15);
        engagementBar.setAlignment(Pos.CENTER_LEFT);

        boolean isLiked = likeDAO.isPostLikedByUser(currentUser.getId(), post.getId());
        
        Button likeButton = new Button(isLiked ? "❤️ " + post.getLikeCount() : "🤍 " + post.getLikeCount());
        likeButton.getStyleClass().add("engagement-button");
        likeButton.setOnAction(e -> handleLikePost(post, likeButton));

        Button commentButton = new Button("💬 " + post.getCommentCount());
        commentButton.getStyleClass().add("engagement-button");

        engagementBar.getChildren().addAll(likeButton, commentButton);

        card.getChildren().addAll(date, content, engagementBar);

        return card;
    }

    private void handleLikePost(Post post, Button likeButton) {
        int userId = currentUser.getId();
        int postId = post.getId();

        boolean isCurrentlyLiked = likeDAO.isPostLikedByUser(userId, postId);

        if (isCurrentlyLiked) {
            if (likeDAO.unlikePost(userId, postId)) {
                postDAO.decrementLikeCount(postId);
                post.setLikeCount(post.getLikeCount() - 1);
                likeButton.setText("🤍 " + post.getLikeCount());
            }
        } else {
            if (likeDAO.likePost(userId, postId)) {
                postDAO.incrementLikeCount(postId);
                post.setLikeCount(post.getLikeCount() + 1);
                likeButton.setText("❤️ " + post.getLikeCount());
            }
        }
    }

    private void handleFollowToggle() {
        boolean isFollowing = followDAO.isFollowing(currentUser.getId(), profileUser.getId());

        if (isFollowing) {
            if (followDAO.unfollowUser(currentUser.getId(), profileUser.getId())) {
                actionButton.setText("Follow");
                int newCount = Integer.parseInt(followersCountText.getText()) - 1;
                followersCountText.setText(String.valueOf(newCount));
            }
        } else {
            if (followDAO.followUser(currentUser.getId(), profileUser.getId())) {
                actionButton.setText("Unfollow");
                int newCount = Integer.parseInt(followersCountText.getText()) + 1;
                followersCountText.setText(String.valueOf(newCount));
            }
        }
    }

    private void handleEditProfile() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Edit Profile");
        dialog.setHeaderText("Update your profile information");

        VBox dialogContent = new VBox(15);
        dialogContent.setPadding(new Insets(20));
        dialogContent.setPrefWidth(400);

        TextArea bioArea = new TextArea(profileUser.getBio());
        bioArea.setPromptText("Tell us about yourself...");
        bioArea.setPrefRowCount(5);

        dialogContent.getChildren().addAll(
            new Label("Bio:"),
            bioArea
        );

        dialog.getDialogPane().setContent(dialogContent);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            profileUser.setBio(bioArea.getText());
            if (userDAO.updateUser(profileUser)) {
                bioText.setText(profileUser.getBio());
                showAlert("Success", "Profile updated successfully!");
            } else {
                showAlert("Error", "Failed to update profile");
            }
        }
    }

    @FXML
    public void handleBackToFeed() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/feed.fxml"));
            Scene scene = new Scene(loader.load(), 1000, 700);
            scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
            
            Stage stage = (Stage) actionButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Social Connect - Feed");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load feed");
        }
    }

    @FXML
    public void handleLogout() {
        SessionManager.getInstance().logout();
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/login.fxml"));
            Scene scene = new Scene(loader.load(), 500, 600);
            scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
            
            Stage stage = (Stage) actionButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Social Connect - Login");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
