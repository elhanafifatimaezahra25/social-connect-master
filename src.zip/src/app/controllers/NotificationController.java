package app.controllers;

import app.dao.NotificationDAO;
import app.dao.UserDAO;
import app.models.Notification;
import app.models.User;
import app.utils.SessionManager;
import app.utils.ThemeManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class NotificationController {

    @FXML private ScrollPane scrollPane;
    @FXML private VBox notificationsContainer;
    @FXML private Label unreadCountLabel;
    @FXML private Button markAllReadButton;
    @FXML private Button backButton;

    private NotificationDAO notificationDAO;
    private int currentUserId;

    public void initialize() {
        notificationDAO = new NotificationDAO();
        currentUserId = SessionManager.getInstance().getCurrentUser().getId();
        
        loadNotifications();
        updateUnreadCount();
    }

    private void loadNotifications() {
        notificationsContainer.getChildren().clear();
        
        List<Notification> notifications = notificationDAO.getUserNotifications(currentUserId);
        
        if (notifications.isEmpty()) {
            Label emptyLabel = new Label("No notifications yet");
            emptyLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: gray; -fx-padding: 50px;");
            notificationsContainer.getChildren().add(emptyLabel);
            return;
        }
        
        for (Notification notification : notifications) {
            notificationsContainer.getChildren().add(createNotificationCard(notification));
        }
    }

    private VBox createNotificationCard(Notification notification) {
        VBox card = new VBox(8);
        card.setPadding(new Insets(15));
        card.setStyle(
            "-fx-background-color: " + (notification.isRead() ? "#f8f9fa" : "#e3f2fd") + ";" +
            "-fx-background-radius: 10px;" +
            "-fx-border-color: #dee2e6;" +
            "-fx-border-radius: 10px;" +
            "-fx-border-width: 1px;"
        );
        
        // Notification icon based on type
        String icon = getIconForType(notification.getType());
        Label typeLabel = new Label(icon + " " + notification.getType());
        typeLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        
        // Notification content
        Label contentLabel = new Label(notification.getContent());
        contentLabel.setWrapText(true);
        contentLabel.setStyle("-fx-font-size: 13px;");
        
        // Timestamp
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy HH:mm");
        Label timeLabel = new Label(notification.getCreatedAt().format(formatter));
        timeLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: gray;");
        
        // Action buttons
        HBox actionBox = new HBox(10);
        Button markReadButton = new Button("Mark as Read");
        markReadButton.getStyleClass().add("action-button");
        markReadButton.setOnAction(e -> {
            notificationDAO.markAsRead(notification.getId());
            loadNotifications();
            updateUnreadCount();
        });
        
        Button deleteButton = new Button("Delete");
        deleteButton.getStyleClass().add("action-button");
        deleteButton.setOnAction(e -> {
            notificationDAO.deleteNotification(notification.getId());
            loadNotifications();
            updateUnreadCount();
        });
        
        if (!notification.isRead()) {
            actionBox.getChildren().add(markReadButton);
        }
        actionBox.getChildren().add(deleteButton);
        
        card.getChildren().addAll(typeLabel, contentLabel, timeLabel, actionBox);
        return card;
    }

    private String getIconForType(String type) {
        switch (type) {
            case "LIKE": return "❤️";
            case "COMMENT": return "💬";
            case "FOLLOW": return "👤";
            case "MENTION": return "@";
            default: return "🔔";
        }
    }

    private void updateUnreadCount() {
        int count = notificationDAO.getUnreadCount(currentUserId);
        unreadCountLabel.setText(count + " unread");
        markAllReadButton.setDisable(count == 0);
    }

    @FXML
    private void handleMarkAllRead() {
        notificationDAO.markAllAsRead(currentUserId);
        loadNotifications();
        updateUnreadCount();
    }

    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/feed.fxml"));
            Scene scene = new Scene(loader.load());
            ThemeManager.initialize(scene);
            
            Stage stage = (Stage) backButton.getScene().getWindow();
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
