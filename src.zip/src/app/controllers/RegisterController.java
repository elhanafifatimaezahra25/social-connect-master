package app.controllers;

import app.dao.UserDAO;
import app.models.User;
import app.utils.PasswordUtil;
import app.utils.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class RegisterController {

    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private Label errorLabel;
    @FXML private Button registerButton;

    private UserDAO userDAO = new UserDAO();

    @FXML
    public void handleRegister() {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText();
        String confirmPassword = confirmPasswordField.getText();

        // Validation
        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            showError("Please fill in all fields");
            return;
        }

        if (username.length() < 3) {
            showError("Username must be at least 3 characters");
            return;
        }

        if (!email.contains("@")) {
            showError("Please enter a valid email address");
            return;
        }

        if (password.length() < 6) {
            showError("Password must be at least 6 characters");
            return;
        }

        if (!password.equals(confirmPassword)) {
            showError("Passwords do not match");
            return;
        }

        // Check if username already exists
        if (userDAO.getUserByUsername(username) != null) {
            showError("Username already taken");
            return;
        }

        // Check if email already exists
        if (userDAO.getUserByEmail(email) != null) {
            showError("Email already registered");
            return;
        }

        // Hash password
        String passwordHash = PasswordUtil.hashPassword(password);

        // Create user
        User newUser = new User(username, email, passwordHash);
        newUser.setBio("Hey there! I'm new to Social Connect.");
        
        User createdUser = userDAO.createUser(newUser);

        if (createdUser != null) {
            // Auto-login after registration
            System.out.println("✅ Account created successfully for: " + createdUser.getUsername());
            SessionManager.getInstance().setCurrentUser(createdUser);
            System.out.println("✅ Session set successfully");
            
            try {
                // Navigate to feed
                System.out.println("📱 Loading feed screen...");
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/feed.fxml"));
                
                if (loader.getLocation() == null) {
                    System.err.println("❌ ERROR: feed.fxml not found!");
                    showError("Error: feed.fxml not found");
                    return;
                }
                
                System.out.println("✅ Found feed.fxml at: " + loader.getLocation());
                Scene scene = new Scene(loader.load(), 1000, 700);
                scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
                
                Stage stage = (Stage) registerButton.getScene().getWindow();
                stage.setScene(scene);
                stage.setTitle("Social Connect - Feed");
                System.out.println("✅ Successfully navigated to feed!");
            } catch (Exception e) {
                System.err.println("❌ ERROR loading feed:");
                e.printStackTrace();
                showError("Error loading feed: " + e.getMessage());
            }
        } else {
            showError("Error creating account. Please try again.");
        }
    }

    @FXML
    public void handleGoToLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/login.fxml"));
            Scene scene = new Scene(loader.load(), 500, 600);
            scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
            
            Stage stage = (Stage) registerButton.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("Social Connect - Login");
        } catch (Exception e) {
            e.printStackTrace();
            showError("Error loading login page");
        }
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
        errorLabel.setManaged(true);
    }
}
