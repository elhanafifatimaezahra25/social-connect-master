package app.models;

import java.time.LocalDateTime;

public class Notification {
    private int id;
    private int userId;
    private String type; // LIKE, COMMENT, FOLLOW, MENTION
    private String content;
    private int relatedId; // post_id, user_id, etc.
    private boolean isRead;
    private LocalDateTime createdAt;

    // Constructors
    public Notification() {}

    public Notification(int userId, String type, String content, int relatedId) {
        this.userId = userId;
        this.type = type;
        this.content = content;
        this.relatedId = relatedId;
        this.isRead = false;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getRelatedId() {
        return relatedId;
    }

    public void setRelatedId(int relatedId) {
        this.relatedId = relatedId;
    }

    public boolean isRead() {
        return isRead;
    }

    public void setRead(boolean read) {
        isRead = read;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
