package app.test;

import app.DBConnection;
import app.dao.UserDAO;
import app.models.User;
import java.sql.Connection;

public class TestConnection {
    
    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println(" Testing Database Connection...");
        System.out.println("========================================\n");
        
        // Test 1: Database Connection
        System.out.println("Test 1: Database Connection");
        try {
            Connection conn = DBConnection.getConnection();
            if (conn != null && !conn.isClosed()) {
                System.out.println(" SUCCESS: Connected to database!");
            } else {
                System.out.println(" FAIL: Connection is null or closed");
            }
        } catch (Exception e) {
            System.out.println(" FAIL: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("\n========================================");
        System.out.println("Test 2: User Operations");
        System.out.println("========================================\n");
        
        // Test 2: UserDAO operations
        UserDAO userDAO = new UserDAO();
        
        try {
            // Check if test user exists
            User existingUser = userDAO.getUserByUsername("testuser");
            
            if (existingUser != null) {
                System.out.println(" Found existing user: " + existingUser.getUsername());
                System.out.println("   Email: " + existingUser.getEmail());
                System.out.println("   Bio: " + existingUser.getBio());
            } else {
                System.out.println("ℹ  No test user found (this is normal for first run)");
            }
            
        } catch (Exception e) {
            System.out.println(" FAIL: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("\n========================================");
        System.out.println(" All tests completed!");
        System.out.println("========================================");
        
        System.out.println("\n Next steps:");
        System.out.println("1. Run Main.java to start the application");
        System.out.println("2. Click 'Sign Up' to create an account");
        System.out.println("3. If you see login screen, database is working!");
        System.out.println("4. After login/register, you should see the feed");
        
        System.out.println("\n If nothing happens after login/register:");
        System.out.println("   - Check console for errors");
        System.out.println("   - Check if feed.fxml exists in resources");
        System.out.println("   - Check if FeedController is properly set up");
    }
}
