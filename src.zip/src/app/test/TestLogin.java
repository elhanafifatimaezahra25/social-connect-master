package app.test;

import app.dao.UserDAO;
import app.models.User;
import app.utils.PasswordUtil;
import app.utils.SessionManager;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TestLogin extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        System.out.println("\n========================================");
        System.out.println(" Testing Login/Register Navigation");
        System.out.println("========================================\n");
        
        // Test creating a user programmatically
        UserDAO userDAO = new UserDAO();
        
        // Check if test user exists
        User testUser = userDAO.getUserByUsername("testuser");
        
        if (testUser == null) {
            System.out.println(" Creating test user...");
            
            // Create test user
            String passwordHash = PasswordUtil.hashPassword("test123");
            User newUser = new User("testuser", "test@test.com", passwordHash);
            newUser.setBio("Test user for debugging");
            
            testUser = userDAO.createUser(newUser);
            
            if (testUser != null) {
                System.out.println(" Test user created successfully!");
                System.out.println("   Username: testuser");
                System.out.println("   Password: test123");
            } else {
                System.out.println(" Failed to create test user");
                return;
            }
        } else {
            System.out.println(" Test user already exists");
            System.out.println("   Username: testuser");
            System.out.println("   Password: test123");
        }
        
        System.out.println("\n Loading login screen...");
        
        // Load login screen
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/login.fxml"));
        Scene scene = new Scene(loader.load(), 500, 600);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        
        stage.setTitle("Social Connect - Login Test");
        stage.setScene(scene);
        stage.show();
        
        System.out.println(" Login screen loaded!");
        System.out.println("\n Instructions:");
        System.out.println("1. Login with: testuser / test123");
        System.out.println("2. Or register a new account");
        System.out.println("3. After login/register, you should see the feed");
        System.out.println("\n  If you don't see feed after login:");
        System.out.println("   Check console for error messages");
        System.out.println("========================================\n");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
