package app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    // MySQL through TCP socket
    private static final String HOST = "127.0.0.1";
    private static final int PORT = 3306;
    private static final String DB_NAME = "testdb";
    private static final String USER = "appuser";
    private static final String PASSWORD = "app123";
    




    private static Connection connection = null;

    public static Connection getConnection() {
        try {
            // Check if connection exists and is valid
            if (connection != null && !connection.isClosed()) {
                return connection;
            }

            // Create new connection
            String url = "jdbc:mysql://127.0.0.1:3306/testdb"
           + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

            System.out.println("Attempting to connect to: " + url);
            System.out.println("User: " + USER);

            connection = DriverManager.getConnection(url, USER, PASSWORD);
            System.out.println("✅ Connected to MySQL successfully!");

            return connection;

        } catch (SQLException e) {
            System.err.println("❌ Failed to connect to MySQL:");
            System.err.println("   Host: " + HOST);
            System.err.println("   Port: " + PORT);
            System.err.println("   Database: " + DB_NAME);
            System.err.println("   User: " + USER);
            System.err.println("   Error: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
