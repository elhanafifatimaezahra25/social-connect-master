package app.dao;

import app.DBConnection;
import app.models.Like;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LikeDAO {

    public boolean likePost(int userId, int postId) {
        String sql = "INSERT INTO likes (post_id, user_id) VALUES (?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            pstmt.setInt(2, userId);
            pstmt.executeUpdate();
            
            return true;
        } catch (SQLException e) {
            // Unique constraint violation means already liked
            return false;
        }
    }

    public boolean unlikePost(int userId, int postId) {
        String sql = "DELETE FROM likes WHERE post_id = ? AND user_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            pstmt.setInt(2, userId);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isPostLikedByUser(int userId, int postId) {
        String sql = "SELECT COUNT(*) FROM likes WHERE post_id = ? AND user_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            pstmt.setInt(2, userId);
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false;
    }

    public List<Like> getLikesByPostId(int postId) {
        List<Like> likes = new ArrayList<>();
        String sql = "SELECT * FROM likes WHERE post_id = ? ORDER BY created_at DESC";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, postId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                likes.add(extractLikeFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return likes;
    }

    private Like extractLikeFromResultSet(ResultSet rs) throws SQLException {
        Like like = new Like();
        like.setId(rs.getInt("id"));
        like.setPostId(rs.getInt("post_id"));
        like.setUserId(rs.getInt("user_id"));
        like.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        return like;
    }
}
