package app.utils;

import javafx.scene.Scene;

public class ThemeManager {
    
    private static boolean isDarkMode = false;
    private static Scene currentScene;
    
    public static void initialize(Scene scene) {
        currentScene = scene;
        applyTheme();
    }
    
    public static void toggleTheme() {
        isDarkMode = !isDarkMode;
        applyTheme();
    }
    
    public static void setDarkMode(boolean darkMode) {
        isDarkMode = darkMode;
        applyTheme();
    }
    
    public static boolean isDarkMode() {
        return isDarkMode;
    }
    
    private static void applyTheme() {
        if (currentScene == null) {
            return;
        }
        
        // Remove all existing stylesheets
        currentScene.getStylesheets().clear();
        
        // Add base styles
        currentScene.getStylesheets().add(
            ThemeManager.class.getResource("/styles.css").toExternalForm()
        );
        
        // Add dark mode if enabled
        if (isDarkMode) {
            currentScene.getStylesheets().add(
                ThemeManager.class.getResource("/dark-mode.css").toExternalForm()
            );
            currentScene.getRoot().getStyleClass().add("dark-mode");
        } else {
            currentScene.getRoot().getStyleClass().remove("dark-mode");
        }
    }
    
    public static String getThemeName() {
        return isDarkMode ? "Dark Mode" : "Light Mode";
    }
}
